package module;

public abstract class History {
   abstract long getDateTime();
}
